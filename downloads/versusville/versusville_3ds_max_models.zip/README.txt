Since all of these models are from pre-production stages of development, some models may use textures that aren't the same as what's used in the final game files.
Any of these old textures (if we have them) will be placed in a "textures" folder with the model

NOTE THAT THIS DOESNT INCLUDE EVERY MODEL (ONLY THE ONES THAT WE HAVE)